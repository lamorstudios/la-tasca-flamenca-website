# Bildquellen & Lizenzen

## Aktueller Stand: Marken-Platzhalter

Alle Bildflächen sind aktuell mit **selbst erzeugten, hochwertigen
Duotone-Platzhaltern** in der Markenfarbwelt gefüllt
(`scripts/gen-placeholders.mjs`, Ausgabe als **WebP + AVIF**).

- **Lizenz:** Eigenerzeugung für dieses Projekt — lizenzfrei, kommerziell
  nutzbar, **keine Namensnennung nötig**.
- **Fotograf:in / Quelle:** entfällt (kein Fremdmaterial).

> Hinweis: Diese Session kann Unsplash/Pexels/Pixabay nicht erreichen
> (Egress-Policy blockiert diese Hosts). Echte Fotos werden daher über das
> mitgelieferte Skript geladen — dort, wo Internetzugriff besteht.

## Echte, lizenzfreie Fotos laden (1 Befehl)

```bash
# kostenloser Key: https://www.pexels.com/api/
PEXELS_API_KEY=dein_key npm run images
```

Das Skript (`scripts/fetch-images.mjs`):
1. sucht pro Bild-Slot ein passendes Foto auf **Pexels** (Themen in
   `scripts/slots.mjs`, Luxury-Hospitality-/Editorial-Stil),
2. speichert es optimiert als **WebP + AVIF** unter identischem Dateinamen,
3. überschreibt diese Datei mit einer **wahrheitsgemäßen Quellenliste**
   (Datei · Motiv · Fotograf:in · Quelle · Original-Link), live aus der API.

**Pexels-Lizenz:** kostenlos, auch kommerziell, ohne Namensnennung —
https://www.pexels.com/license/ · Kein Pinterest, keine Wasserzeichen,
keine KI-Bilder.

## Eigene Restaurantfotos einsetzen

Dateien unter `public/images/...` mit gleichem Namen ersetzen
(je `.webp` und `.avif`; `og/og-default` zusätzlich `.jpg`). Seitenverhältnisse
siehe `scripts/slots.mjs`. Alt-Texte sind dort ebenfalls hinterlegt.
